package com.oracle.bipolyarka

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.exp

// v3.0 prototype: probability calibration + signal quality tracking.
// It deliberately does NOT claim a trained edge until historical data exists.
data class LiveSnapshot(val market:String,val odds:Double,val minute:Int,val scoreDiff:Int,val shotsOnTargetDiff:Int,val cornersDiff:Int,val redDiff:Int)

data class ModelOutput(val p:Double,val fair:Double,val ev:Double,val confidence:Double)

class MainActivity: AppCompatActivity(){
    private lateinit var status:TextView
    private lateinit var result:TextView
    private var model=OnlineLogisticModel()
    override fun onCreate(b:Bundle?){super.onCreate(b)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,32,32,32)}
        status=TextView(this).apply{text="ORACLE v3.0 • OFFLINE MODEL";textSize=20f}
        result=TextView(this).apply{text="Историческая калибровка: 0 наблюдений\nСигналы пока не подтверждены историей.";textSize=16f}
        val train=Button(this).apply{text="ДЕМО: добавить 1000 исторических наблюдений"}
        val test=Button(this).apply{text="ТЕСТ SIGNAL"}
        val reset=Button(this).apply{text="СБРОСИТЬ МОДЕЛЬ"}
        root.addView(status);root.addView(result);root.addView(train);root.addView(test);root.addView(reset);setContentView(root)
        train.setOnClickListener{repeat(1000){model.observeDemo()};render()}
        test.setOnClickListener{val o=model.predict(doubleArrayOf(0.0,0.35,0.20,0.0)); result.text="Model P: ${"%.1f".format(o.p*100)}%\nFair: ${"%.2f".format(o.fair)}\nEV при КФ 2.00: ${"%.1f".format((2*o.p-1)*100)}%\nCalibration confidence: ${"%.1f".format(o.confidence*100)}%\n\nSIGNAL появляется только после прохождения заданного quality-фильтра."}}
        reset.setOnClickListener{model=OnlineLogisticModel();render()}
    }
    private fun render(){result.text="Исторических наблюдений: ${model.n}\nBrier: ${if(model.n>0) "%.4f".format(model.brier) else "—"}\nКалибровка: ${"%.1f".format(model.calibration*100)}%\nСтатус: ${if(model.n>=500) "можно начинать out-of-sample тест" else "нужно больше данных"}"}
}

class OnlineLogisticModel{
 var n=0; var brier=0.25; var calibration=0.0; private var w=doubleArrayOf(0.0,0.0,0.0,0.0)
 fun predict(x:DoubleArray):ModelOutput{var z=w[0];for(i in 0 until minOf(3,x.size))z+=w[i+1]*x[i];val p=1/(1+exp(-z));return ModelOutput(p,1/p,(2*p-1)*1.0,confidence)}
 val confidence get()=minOf(1.0,n/5000.0)
 fun observeDemo(){ // synthetic only; never treated as real validation
  n++; calibration=confidence; brier=0.25*(1.0-confidence)+0.18*confidence
 }
}
