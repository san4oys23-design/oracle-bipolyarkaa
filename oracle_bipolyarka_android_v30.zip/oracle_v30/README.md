# Oracle Биполярка v3.0 — calibrated model / backtest foundation

Цель: заменить эвристический SIGNAL измеримой моделью, но не выдавать ложную гарантию выигрыша.

## Что добавлено
- исторические snapshots live-линии;
- признаки: минута, счёт, удары в створ, угловые, удаления, КФ;
- хронологическое train/validation/test разделение;
- Brier Score и Log Loss;
- confidence зависит от размера реальной базы;
- подготовка к калибровке вероятностей и ROI/просадке;
- Android UI показывает, когда данных недостаточно для доверительного сигнала.

## Важно
Кнопка demo добавляет СИНТЕТИЧЕСКИЕ наблюдения только для проверки UI. Они не являются доказательством качества модели и не должны использоваться для ставок.

## Сборка
Открой проект в Android Studio и Build > Generate APK. Для CI есть место под GitHub Actions.

## Исторический CSV
trainer/train.py принимает CSV с колонками:
sport,market,timestamp,minute,home_goals,away_goals,sot_home,sot_away,corners_home,corners_away,reds_home,reds_away,odds,outcome

Результаты TEST должны считаться только на данных, которые модель не видела при обучении.
