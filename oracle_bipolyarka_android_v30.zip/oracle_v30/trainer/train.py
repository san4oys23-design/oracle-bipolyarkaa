"""Offline trainer for Oracle v3.0.
Input CSV columns: sport,market,minute,home_goals,away_goals,sot_home,sot_away,corners_home,corners_away,reds_home,reds_away,odds,outcome
outcome must be 0/1. Uses chronological split: train -> validation -> test.
This script is a scaffold; do not use synthetic/demo data as evidence of profitability.
"""
import csv, math, sys
from pathlib import Path

def sigmoid(z): return 1/(1+math.exp(-max(-30,min(30,z))))
def fit(rows, epochs=300, lr=.03):
    w=[0.0]*8
    for _ in range(epochs):
      for r in rows:
        x=[1, r['minute']/90, r['home_goals']-r['away_goals'], r['sot_home']-r['sot_away'], r['corners_home']-r['corners_away'], r['reds_home']-r['reds_away'], 1/r['odds'], 1.0]
        y=r['outcome']; p=sigmoid(sum(a*b for a,b in zip(w,x)))
        for i in range(len(w)): w[i]+=lr*(y-p)*x[i]
    return w

def metrics(rows,w):
    if not rows:return {}
    bs=0;ll=0
    for r in rows:
      x=[1,r['minute']/90,r['home_goals']-r['away_goals'],r['sot_home']-r['sot_away'],r['corners_home']-r['corners_away'],r['reds_home']-r['reds_away'],1/r['odds'],1]
      p=sigmoid(sum(a*b for a,b in zip(w,x))); y=r['outcome'];bs+=(p-y)**2;ll-=y*math.log(max(p,1e-9))+(1-y)*math.log(max(1-p,1e-9))
    return {'n':len(rows),'brier':bs/len(rows),'logloss':ll/len(rows)}

if __name__=='__main__':
 p=Path(sys.argv[1] if len(sys.argv)>1 else 'history.csv')
 rows=[]
 with p.open(newline='',encoding='utf-8') as f:
  for r in csv.DictReader(f):
   for k in ['minute','home_goals','away_goals','sot_home','sot_away','corners_home','corners_away','reds_home','reds_away','odds','outcome']:r[k]=float(r[k])
   rows.append(r)
 rows.sort(key=lambda r:r.get('timestamp',''))
 a=int(len(rows)*.6);b=int(len(rows)*.8);w=fit(rows[:a])
 print('TRAIN',metrics(rows[:a],w));print('VALIDATION',metrics(rows[a:b],w));print('TEST',metrics(rows[b:],w))
